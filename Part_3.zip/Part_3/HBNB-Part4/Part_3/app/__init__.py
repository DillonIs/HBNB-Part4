# app/__init__.py
import os
from flask import Flask
from flask_restx import Api
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from app.api.v1.users import api as users_ns
from app.api.v1.amenities import api as amenities_ns
from app.api.v1.places import api as places_ns
from app.api.v1.reviews import api as reviews_ns
from app.api.v1.auth import api as auth_ns
from app.api.v1.protected import api as protected_ns

BASE_DIR = os.path.dirname(os.path.abspath(__file__))        # .../Part_3/app
TEMPLATE_DIR = os.path.join(BASE_DIR, '..', 'templates')     # .../Part_3/templates
STATIC_DIR   = os.path.join(BASE_DIR, '..', 'static')        # .../Part_3/static

def create_app():
    app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

    CORS(app, resources={r"/api/v1/*": {"origins": "*"}})
    api = Api(app,
              version='1.0',
              title='HBnB API',
              description='HBnB Application API',
              doc='/swagger')   # Swagger at /swagger, not /

    # Namespaces under /api/v1/...
    api.add_namespace(users_ns,     path='/api/v1/users')
    api.add_namespace(amenities_ns, path='/api/v1/amenities')
    api.add_namespace(places_ns,    path='/api/v1/places')
    api.add_namespace(reviews_ns,   path='/api/v1/reviews')
    api.add_namespace(auth_ns,      path='/api/v1/auth')
    api.add_namespace(protected_ns, path='/api/v1/protected')

    app.config['JWT_SECRET_KEY'] = 'your_jwt_secret_key'
    JWTManager(app)
    return app
